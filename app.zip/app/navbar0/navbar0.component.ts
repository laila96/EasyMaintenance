import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar0',
  templateUrl: './navbar0.component.html',
  styleUrls: ['./navbar0.component.css']
})
export class Navbar0Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

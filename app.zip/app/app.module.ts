import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule} from '@angular/common/http';
import { RouterModule} from '@angular/router';
import { FormsModule} from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatCardModule, MatToolbarModule } from '@angular/material';
import { MatInputModule } from '@angular/material';

import { AppComponent } from './app.component';
import { Navbar0Component } from './navbar0/navbar0.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { ApiService } from './api.service';
import { SliderModule } from './slider/slider.module';
//import { SliderComponent } from './slider/slider.component';
//import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
//import { SliderComponent } from './slider/slider.component';

@NgModule({
  declarations: [
    AppComponent,
    Navbar0Component,
    RegisterComponent,
    LoginComponent,
    //SliderComponent
    //SliderComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    MatCardModule,
    SliderModule,
    MatButtonModule, MatToolbarModule, MatInputModule,
    RouterModule.forRoot([
      {path:"register", component: RegisterComponent},
      {path:"login", component: LoginComponent}
    ])
  ],
  providers: [ApiService],
  bootstrap: [AppComponent]
})
export class AppModule { }

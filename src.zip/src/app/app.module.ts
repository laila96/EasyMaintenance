import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule} from '@angular/common/http';
import { RouterModule} from '@angular/router';
import { FormsModule} from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatCardModule, MatToolbarModule } from '@angular/material';
import { MatInputModule } from '@angular/material';

import { AppComponent } from './app.component';
import { Navbar0Component } from './navbar0/navbar0.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { ApiService } from './api.service';
import { SliderModule } from './slider/slider.module';
import { ConnectionComponent } from './connection/connection.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { AjouterComponent } from './ajouter/ajouter.component';
import { ListeComponent } from './liste/liste.component';
import { ChoixComponent } from './choix/choix.component';
import { LoginAdminComponent } from './login-admin/login-admin.component';
import { ConnectionAdminComponent } from './connection-admin/connection-admin.component';
import { LoginTechComponent } from './login-tech/login-tech.component';
import { ConnectionTechComponent } from './connection-tech/connection-tech.component';
//import { SliderComponent } from './slider/slider.component';
//import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
//import { SliderComponent } from './slider/slider.component';

@NgModule({
  declarations: [
    AppComponent,
    Navbar0Component,
    RegisterComponent,
    LoginComponent,
    ConnectionComponent,
    AboutComponent,
    ContactComponent,
    AjouterComponent,
    ListeComponent,
    ChoixComponent,
    LoginAdminComponent,
    ConnectionAdminComponent,
    LoginTechComponent,
    ConnectionTechComponent,
    //SliderComponent
    //SliderComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    MatCardModule,
    SliderModule,
    MatButtonModule, MatToolbarModule, MatInputModule,
    RouterModule.forRoot([
      {path:"register", component: RegisterComponent},
      {path:"login", component: LoginComponent},
      {path:"connection", component: ConnectionComponent},
      {path:"about", component: AboutComponent},
      {path:"contact", component: ContactComponent},
      {path:"creat", component: AjouterComponent},
      {path:"liste", component: ListeComponent},
      {path:"choix", component: ChoixComponent},
      {path:"loginadmin", component: LoginAdminComponent},
      {path:"connectionadmin", component: ConnectionAdminComponent},
      {path:"logintech", component: LoginTechComponent},
      {path:"connectiontech", component: ConnectionTechComponent}
    ])
  ],
  providers: [ApiService],
  bootstrap: [AppComponent]
})
export class AppModule { }

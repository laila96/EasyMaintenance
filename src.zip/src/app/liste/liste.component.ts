import { Component, OnInit } from '@angular/core';
//import { Reclammation } from '../mock-heroes';
@Component({
  selector: 'app-liste',
  templateUrl: './liste.component.html',
  styleUrls: ['./liste.component.css']
})
export class ListeComponent implements OnInit {

  //list = NameTable;
  //selectedReclamation: Reclamation;
  //onSelect(reclamation: Reclamation): void {
  //this.selectedReclamation = reclamation;
//}
  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-connection-tech',
  templateUrl: './connection-tech.component.html',
  styleUrls: ['./connection-tech.component.css']
})
export class ConnectionTechComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

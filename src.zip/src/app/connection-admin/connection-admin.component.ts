import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-connection-admin',
  templateUrl: './connection-admin.component.html',
  styleUrls: ['./connection-admin.component.css']
})
export class ConnectionAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

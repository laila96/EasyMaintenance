import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-tech',
  templateUrl: './login-tech.component.html',
  styleUrls: ['./login-tech.component.css']
})
export class LoginTechComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
